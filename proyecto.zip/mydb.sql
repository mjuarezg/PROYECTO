CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidato`
--

DROP TABLE IF EXISTS `candidato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidato` (
  `Usuario basico_id` varchar(45) NOT NULL,
  `Oferta_id` int(11) NOT NULL,
  `fechaInscripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`Usuario basico_id`,`Oferta_id`),
  KEY `fk_Usuario basico_has_Oferta_Oferta1_idx` (`Oferta_id`),
  KEY `fk_Usuario basico_has_Oferta_Usuario basico1_idx` (`Usuario basico_id`),
  CONSTRAINT `fk_Usuario basico_has_Oferta_Oferta1` FOREIGN KEY (`Oferta_id`) REFERENCES `oferta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Usuario basico_has_Oferta_Usuario basico1` FOREIGN KEY (`Usuario basico_id`) REFERENCES `usuariobasico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidato`
--

LOCK TABLES `candidato` WRITE;
/*!40000 ALTER TABLE `candidato` DISABLE KEYS */;
/*!40000 ALTER TABLE `candidato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `id` varchar(45) NOT NULL,
  `clave` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `Provincia_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Empresa_Provincia1_idx` (`Provincia_id`),
  CONSTRAINT `fk_Empresa_Provincia1` FOREIGN KEY (`Provincia_id`) REFERENCES `provincia` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresabloqueada`
--

DROP TABLE IF EXISTS `empresabloqueada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresabloqueada` (
  `fechaInicio` date NOT NULL,
  `fechaFin` date NOT NULL,
  `Empresa_id` varchar(45) NOT NULL,
  PRIMARY KEY (`Empresa_id`),
  CONSTRAINT `fk_EmpresaBloqueada_Empresa1` FOREIGN KEY (`Empresa_id`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresabloqueada`
--

LOCK TABLES `empresabloqueada` WRITE;
/*!40000 ALTER TABLE `empresabloqueada` DISABLE KEYS */;
/*!40000 ALTER TABLE `empresabloqueada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensaje`
--

DROP TABLE IF EXISTS `mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensaje` (
  `id` int(11) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `contenido` varchar(45) NOT NULL,
  `fechaEnvio` date NOT NULL,
  `privado` tinyint(1) NOT NULL,
  `leido` tinyint(1) NOT NULL,
  `destinatario` varchar(45) NOT NULL,
  `receptorUsuario` varchar(45) NOT NULL DEFAULT '',
  `receptorEmpresa` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`,`receptorUsuario`,`receptorEmpresa`),
  KEY `fk_Mensaje_Usuario basico1_idx` (`receptorUsuario`),
  KEY `fk_Mensaje_Empresa1_idx` (`receptorEmpresa`),
  CONSTRAINT `fk_Mensaje_Empresa1` FOREIGN KEY (`receptorEmpresa`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Mensaje_Usuario basico1` FOREIGN KEY (`receptorUsuario`) REFERENCES `usuariobasico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensaje`
--

LOCK TABLES `mensaje` WRITE;
/*!40000 ALTER TABLE `mensaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensaje_has_empresa`
--

DROP TABLE IF EXISTS `mensaje_has_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensaje_has_empresa` (
  `Mensaje_id` int(11) NOT NULL,
  `Empresa_id` varchar(45) NOT NULL,
  PRIMARY KEY (`Mensaje_id`,`Empresa_id`),
  KEY `fk_Mensaje_has_Empresa_Empresa1_idx` (`Empresa_id`),
  KEY `fk_Mensaje_has_Empresa_Mensaje1_idx` (`Mensaje_id`),
  CONSTRAINT `fk_Mensaje_has_Empresa_Empresa1` FOREIGN KEY (`Empresa_id`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Mensaje_has_Empresa_Mensaje1` FOREIGN KEY (`Mensaje_id`) REFERENCES `mensaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensaje_has_empresa`
--

LOCK TABLES `mensaje_has_empresa` WRITE;
/*!40000 ALTER TABLE `mensaje_has_empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensaje_has_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oferta`
--

DROP TABLE IF EXISTS `oferta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oferta` (
  `id` int(11) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `fechaPublicacion` date NOT NULL,
  `abierta` tinyint(1) NOT NULL,
  `salario` int(11) DEFAULT NULL,
  `jornada` varchar(45) DEFAULT NULL,
  `contrato` varchar(45) DEFAULT NULL,
  `Empresa_id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Oferta_Empresa1_idx` (`Empresa_id`),
  CONSTRAINT `fk_Oferta_Empresa1` FOREIGN KEY (`Empresa_id`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oferta`
--

LOCK TABLES `oferta` WRITE;
/*!40000 ALTER TABLE `oferta` DISABLE KEYS */;
/*!40000 ALTER TABLE `oferta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincia`
--

LOCK TABLES `provincia` WRITE;
/*!40000 ALTER TABLE `provincia` DISABLE KEYS */;
/*!40000 ALTER TABLE `provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sector` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seleccionado`
--

DROP TABLE IF EXISTS `seleccionado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seleccionado` (
  `Usuario basico_id` varchar(45) NOT NULL,
  `Oferta_id` int(11) NOT NULL,
  `Empresa_id` varchar(45) NOT NULL,
  `fechaSeleccion` date NOT NULL,
  `puntuacion` int(11) DEFAULT NULL,
  `comentario` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Usuario basico_id`,`Oferta_id`,`Empresa_id`),
  KEY `fk_Candidatos_has_Empresa_Empresa1_idx` (`Empresa_id`),
  KEY `fk_Candidatos_has_Empresa_Candidatos1_idx` (`Usuario basico_id`,`Oferta_id`),
  CONSTRAINT `fk_Candidatos_has_Empresa_Candidatos1` FOREIGN KEY (`Usuario basico_id`, `Oferta_id`) REFERENCES `candidato` (`Usuario basico_id`, `Oferta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Candidatos_has_Empresa_Empresa1` FOREIGN KEY (`Empresa_id`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seleccionado`
--

LOCK TABLES `seleccionado` WRITE;
/*!40000 ALTER TABLE `seleccionado` DISABLE KEYS */;
/*!40000 ALTER TABLE `seleccionado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timestamps`
--

DROP TABLE IF EXISTS `timestamps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timestamps` (
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timestamps`
--

LOCK TABLES `timestamps` WRITE;
/*!40000 ALTER TABLE `timestamps` DISABLE KEYS */;
/*!40000 ALTER TABLE `timestamps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuariobasico`
--

DROP TABLE IF EXISTS `usuariobasico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuariobasico` (
  `clave` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `administrador` tinyint(1) NOT NULL,
  `Provincia_id` int(11) NOT NULL,
  `sector_id` int(11) NOT NULL,
  `id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Usuario basico_Provincia_idx` (`Provincia_id`),
  KEY `fk_Usuario basico_sector1_idx` (`sector_id`),
  CONSTRAINT `fk_Usuario basico_Provincia` FOREIGN KEY (`Provincia_id`) REFERENCES `provincia` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Usuario basico_sector1` FOREIGN KEY (`sector_id`) REFERENCES `sector` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuariobasico`
--

LOCK TABLES `usuariobasico` WRITE;
/*!40000 ALTER TABLE `usuariobasico` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuariobasico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuariobasico_has_mensaje`
--

DROP TABLE IF EXISTS `usuariobasico_has_mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuariobasico_has_mensaje` (
  `Usuariobasico_id` varchar(45) NOT NULL,
  `Mensaje_id` int(11) NOT NULL,
  PRIMARY KEY (`Usuariobasico_id`,`Mensaje_id`),
  KEY `fk_Usuariobasico_has_Mensaje_Mensaje1_idx` (`Mensaje_id`),
  KEY `fk_Usuariobasico_has_Mensaje_Usuariobasico1_idx` (`Usuariobasico_id`),
  CONSTRAINT `fk_Usuariobasico_has_Mensaje_Mensaje1` FOREIGN KEY (`Mensaje_id`) REFERENCES `mensaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Usuariobasico_has_Mensaje_Usuariobasico1` FOREIGN KEY (`Usuariobasico_id`) REFERENCES `usuariobasico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuariobasico_has_mensaje`
--

LOCK TABLES `usuariobasico_has_mensaje` WRITE;
/*!40000 ALTER TABLE `usuariobasico_has_mensaje` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuariobasico_has_mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuariobloqueado`
--

DROP TABLE IF EXISTS `usuariobloqueado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuariobloqueado` (
  `fechaInicio` date NOT NULL,
  `fechaFin` date NOT NULL,
  `Usuario basico_id` varchar(45) NOT NULL,
  PRIMARY KEY (`Usuario basico_id`),
  CONSTRAINT `fk_UsuarioBloqueado_Usuario basico1` FOREIGN KEY (`Usuario basico_id`) REFERENCES `usuariobasico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuariobloqueado`
--

LOCK TABLES `usuariobloqueado` WRITE;
/*!40000 ALTER TABLE `usuariobloqueado` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuariobloqueado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-15 19:46:03
